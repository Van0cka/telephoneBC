package com.phonecompany.billing;

import com.phonecompany.billing.impl.Call;
import com.phonecompany.billing.impl.MyCalculator;
import junit.framework.Assert;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static com.phonecompany.billing.impl.MyCalculator.PATTERN;

public class MyCalculatorTest {
    private static final DateTimeFormatter FORM = DateTimeFormatter.ofPattern(PATTERN);
    // "dd-MM-yyyy HH:mm:ss"
    private static final LocalDateTime START_CHEAP = LocalDateTime.parse("13-01-2020 17:01:02", FORM);
    private static final LocalDateTime START_EXPENSIVE = LocalDateTime.parse("14-02-2021 08:11:12", FORM);

    @Test
    void load() {
        Call loaded = MyCalculator.load("420774577453,13-01-2020 18:10:15,13-01-2020 18:12:57");
        Call expected = Call.of("420774577453",
                LocalDateTime.of(2020, 1, 13, 18, 10, 15),
                LocalDateTime.of(2020, 1, 13, 18, 12, 57));
        Assert.assertEquals(expected, loaded);
    }

    @Test
    void calculateCall_2s_expensive() {
        BigDecimal sum = MyCalculator.calculateCall(
                Call.of("0", START_EXPENSIVE, START_EXPENSIVE.plusSeconds(2)));
        Assert.assertEquals(BigDecimal.valueOf(1.0), sum);
    }

    @Test
    void calculateCall_2s_cheap() {
        BigDecimal sum = MyCalculator.calculateCall(
                Call.of("0", START_CHEAP, START_CHEAP.plusSeconds(2)));
        Assert.assertEquals(BigDecimal.valueOf(0.5), sum);
    }

    @Test
    void calculateCall_1_59_expensive() {
        LocalDateTime start = START_EXPENSIVE;
        LocalDateTime end = start.plusSeconds(59).plusMinutes(1);
        BigDecimal sum = MyCalculator.calculateCall(Call.of("0", start, end));
        Assert.assertEquals(BigDecimal.valueOf(2.0), sum);
    }

    @Test
    void calculateCall_1_59_cheap() {
        LocalDateTime start = START_CHEAP;
        LocalDateTime end = start.plusSeconds(59).plusMinutes(1);
        BigDecimal sum = MyCalculator.calculateCall(Call.of("0", start, end));
        Assert.assertEquals(BigDecimal.valueOf(1.0), sum);
    }

    @Test
    void calculateCall_2m_exp() {
        LocalDateTime start = START_EXPENSIVE;
        LocalDateTime end = start.plusMinutes(2);
        BigDecimal sum = MyCalculator.calculateCall(Call.of("0", start, end));
        Assert.assertEquals(BigDecimal.valueOf(2.0), sum);
    }

    @Test
    void calculateCall_2m_cheap() {
        LocalDateTime start = START_CHEAP;
        LocalDateTime end = start.plusMinutes(2);
        BigDecimal sum = MyCalculator.calculateCall(Call.of("0", start, end));
        Assert.assertEquals(BigDecimal.valueOf(1.0), sum);
    }

    @Test
    void calculateCall_2h_e() {
        LocalDateTime start = START_EXPENSIVE;
        LocalDateTime end = start.plusHours(2);
        BigDecimal sum = MyCalculator.calculateCall(Call.of("0", start, end));
        Assert.assertEquals(BigDecimal.valueOf(28.0), sum);
    }

    @Test
    void calculateCall_2h_cheap() {
        LocalDateTime start = START_CHEAP;
        LocalDateTime end = start.plusHours(2);
        BigDecimal sum = MyCalculator.calculateCall(Call.of("0", start, end));
        Assert.assertEquals(BigDecimal.valueOf(25.5), sum);
    }

    @Test
    void calculateCall_2d_e() {
        LocalDateTime start = START_EXPENSIVE;
        LocalDateTime end = start.plusDays(2);
        BigDecimal sum = MyCalculator.calculateCall(Call.of("0", start, end));
        Assert.assertEquals(BigDecimal.valueOf(580.0), sum);
    }

    @Test
    void calculateCall_2d_cheap() {
        LocalDateTime start = START_CHEAP;
        LocalDateTime end = start.plusDays(2);
        BigDecimal sum = MyCalculator.calculateCall(Call.of("0", start, end));
        Assert.assertEquals(BigDecimal.valueOf(577.5), sum);
    }

    @Test
    void calculateCall_2_23_59_59_e() {
        LocalDateTime start = START_EXPENSIVE;
        LocalDateTime end = start.plusSeconds(59).plusMinutes(59).plusHours(23).plusDays(2);
        BigDecimal sum = MyCalculator.calculateCall(Call.of("0", start, end));
        Assert.assertEquals(BigDecimal.valueOf(867.8), sum);
    }

    @Test
    void calculateCall_2_23_59_59_cheap() {
        LocalDateTime start = START_CHEAP;
        LocalDateTime end = start.plusSeconds(59).plusMinutes(59).plusHours(23).plusDays(2);
        BigDecimal sum = MyCalculator.calculateCall(Call.of("0", start, end));
        Assert.assertEquals(BigDecimal.valueOf(865.3), sum);
    }

    @Test
    void calculate() {
        // TODO not implemented, try running App with sample,csv or sample2.csv
    }
}
