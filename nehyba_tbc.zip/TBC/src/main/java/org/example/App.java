package org.example;

import com.phonecompany.billing.impl.MyCalculator;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;

public class App {
    static MyCalculator mc = new MyCalculator();
    public static void main(String[] args) {
        System.out.println("Telephone Bill Calculator");
        String content;
        try {
            content = Files.readString(Paths.get("sample.csv"));
        } catch (IOException e) {
            System.err.println("Unable to load sample file. Check path.");
            throw new RuntimeException(e);
        }
        //System.out.println("Content: \n" + content);
        BigDecimal bill = mc.calculate(content);
        System.out.println("Bill is: " + bill);
    }
}
