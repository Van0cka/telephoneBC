package com.phonecompany.billing.impl;

import java.time.LocalDateTime;
import java.util.Objects;
//import java.util.UUID;

public class Call {

//    private final String id;
    String number;
    LocalDateTime start;
    LocalDateTime end;

    public Call(String number, LocalDateTime start, LocalDateTime end) {
//        this.id = UUID.randomUUID().toString();
        this.number = number;
        this.start = start;
        this.end = end;
    }

    public static Call of(String number, LocalDateTime start, LocalDateTime end) {
        return new Call(number, start, end);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Call call = (Call) o;
        return /*id.equals(call.id) &&*/ number.equals(call.number) && start.equals(call.start) && end.equals(call.end);
    }

    @Override
    public int hashCode() {
        return Objects.hash(/*id,*/ number, start, end);
    }

    @Override
    public String toString() {
        return "Call{" +
              /*  "id='" + id + '\'' +*/
                ", number='" + number + '\'' +
                ", start=" + start +
                ", end=" + end +
                '}';
    }
}
