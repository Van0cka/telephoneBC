package com.phonecompany.billing.impl;

import com.phonecompany.billing.TelephoneBillCalculator;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MyCalculator implements TelephoneBillCalculator {
    public static final String PATTERN = "dd-MM-yyyy HH:mm:ss";
    public static final BigDecimal RATE_HIGH = BigDecimal.valueOf(1.0);
    public static final BigDecimal RATE_LOW = BigDecimal.valueOf(0.5);
    public static final BigDecimal RATE_OVER = BigDecimal.valueOf(0.2);
    private static final DateTimeFormatter FORM = DateTimeFormatter.ofPattern(PATTERN);

    public BigDecimal calculate(String phoneLog) {
        String[] rows = phoneLog.split("\n");
        Map<String, BigDecimal> numberWithSum = new HashMap<>();
        Map<String, Integer> callCountByNumber = new HashMap<>();
        // for every row
        for (String row : rows) {
            // load call info: number, start, end
            Call call = load(row);
            // fill map with number and sum of its call price
            BigDecimal price = numberWithSum.containsKey(call.number) ? numberWithSum.get(call.number) : BigDecimal.ZERO;
            numberWithSum.put(call.number, price.add(calculateCall(call)));
            // fill map with number and the occurrence
            callCountByNumber.merge(call.number, 1, Integer::sum);
        }

        //apply promo ~ picking up the most used number
        List<String> mostCommon = getKeysWithMaxValue(callCountByNumber);
        String oneCommon = null;
        BigDecimal highest = new BigDecimal(0);
        for (String s : mostCommon) {
            if (oneCommon == null) {
                highest = new BigDecimal(s);
                oneCommon = s;
            } else {
                BigDecimal aritmeticValue = new BigDecimal(s);
                if (aritmeticValue.compareTo(highest) > 0) {
                    highest = aritmeticValue;
                    oneCommon = s;
                }
            }
        }
        // the most used number (with highest aritmetic value) is ignored
        // not important: BigDecimal bigDecimal = numberWithSum.get(oneCommon);
        numberWithSum.put(oneCommon, BigDecimal.ZERO);

        BigDecimal finalSum = BigDecimal.ZERO;

        for (BigDecimal value : numberWithSum.values()) {
            finalSum = finalSum.add(value);
        }
        return finalSum;
    }

    private static List<String> getKeysWithMaxValue(Map<String, Integer> map) {
        List<String> keysWithMaxValue = new ArrayList<>();
        int maxValue = Collections.max(map.values());
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            if (entry.getValue() == maxValue) {
                keysWithMaxValue.add(entry.getKey());
            }
        }
        return keysWithMaxValue;
    }

    public static Call load(String row) {
        String[] items = row.split(",");
        LocalDateTime start = LocalDateTime.parse(items[1], FORM);
        String endString = items[2];
        int length = endString.length(); // "\r" on last row..
        if ('\r' == endString.charAt(length - 1)) {
            endString = endString.substring(0, length - 1);
        }
        LocalDateTime end = LocalDateTime.parse(endString, FORM);
        return Call.of(items[0], start, end);
    }

    public static BigDecimal calculateCall(Call c) {
        BigDecimal sum = new BigDecimal(0.0);
        // TODO remove unused vars
        int da1 = c.start.getDayOfMonth();
        int mo1 = c.start.getMonthValue();
        int ye1 = c.start.getYear();
        int h1 = c.start.getHour();
        int m1 = c.start.getMinute();
        int s1 = c.start.getSecond();

        int da2 = c.end.getDayOfMonth();
        int mo2 = c.end.getMonthValue();
        int ye2 = c.end.getYear();
        int h2 = c.end.getHour();
        int m2 = c.end.getMinute();
        int s2 = c.end.getSecond();
        // TODO check the end is not before start, I assume it is valid
        long minutesCount = Duration.between(c.start, c.end).toMinutes();

        if (minutesCount == 0) { // calls shorter than 1 minute
            sum = sum.add((h1 >= 8 && h1 < 16) ? RATE_HIGH : RATE_LOW);

        } else {
            if (minutesCount >= 5) {
                // count first 5 minutes and rest is RATE_OVER (0.2)
                // starting with calculation of the rest:
                sum = sum.add(RATE_OVER.multiply(BigDecimal.valueOf(minutesCount - 5)));
                minutesCount = 5;
            }
            // calculation in first <=5 minutes
            if (minutesCount < 5 && s2 != s1) minutesCount++; // minutes are calculated as 1:59 -> 1.. so +1 necessary

            for (int i = 0; i < minutesCount; i++) {
                if (h1 >= 8 && ((h1 < 15 || (h1 == 15) && (m1 + i) < 60))) { // 15:58:59 +0 +1 +2 +3 ~ H H L L
                    sum = sum.add(RATE_HIGH);
                } else {
                    sum = sum.add(RATE_LOW);
                }
            }
        }
        return sum;
    }
}
